
class Machine:
    def __init__(self,ide,typ):
        self.ide = ide
        self.typ = typ
        

