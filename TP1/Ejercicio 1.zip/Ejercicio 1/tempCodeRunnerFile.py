origin = generate(origin, d, 1)
end = np.zeros((d,1))
end = generate(end, d, 1)
obstacles = np.zeros((d,o))
obstacles = generate(obstacles, d, o)
position = origin