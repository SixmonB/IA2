    
class Machine(object):
    
    def __init__(self,ide,typ):
        self.ide = ide  # identificador de la maquina
        self.typ = typ  # tipo de la maquina
        

