
        n = randint(0, len(almacen.halls)-1)
        a = almacen.halls[n]
        orden.append(Punto(almacen.h